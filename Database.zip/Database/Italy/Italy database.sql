-- Disable foreign key checks to allow table creation in any order
SET FOREIGN_KEY_CHECKS = 0;

-- ==========================================
-- TABLE DEFINITIONS (MySQL Syntax)
-- ==========================================

DROP TABLE IF EXISTS sensitivity_results;
DROP TABLE IF EXISTS uncertainty_metrics;
DROP TABLE IF EXISTS event_summary;
DROP TABLE IF EXISTS events;

CREATE TABLE events (
    event_id INT NOT NULL AUTO_INCREMENT,
    event_name VARCHAR(255) NOT NULL,
    country VARCHAR(100),
    year INT,
    event_type_main VARCHAR(100),
    event_type_secondary VARCHAR(100),
    description TEXT,
    PRIMARY KEY (event_id)
) ENGINE=InnoDB;

CREATE TABLE event_summary (
    summary_id INT NOT NULL AUTO_INCREMENT,
    event_id INT NOT NULL,
    total_rainfall_mm DOUBLE,
    mean_rainfall_per_timestep_mm DOUBLE,
    rainfall_ci_low_mm DOUBLE,
    rainfall_ci_high_mm DOUBLE,
    total_runoff_mm DOUBLE,
    mean_runoff_per_timestep_mm DOUBLE,
    runoff_ci_low_mm DOUBLE,
    runoff_ci_high_mm DOUBLE,
    runoff_coefficient_ro_tp DOUBLE,
    n_timesteps INT,
    PRIMARY KEY (summary_id),
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE uncertainty_metrics (
    uncertainty_id INT NOT NULL AUTO_INCREMENT,
    event_id INT NOT NULL,
    variable_name VARCHAR(100) NOT NULL,
    n INT,
    mean_value DOUBLE,
    unit VARCHAR(50),
    std DOUBLE,
    cv DOUBLE,
    ci_low DOUBLE,
    ci_high DOUBLE,
    uncertainty_level VARCHAR(50),
    PRIMARY KEY (uncertainty_id),
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE sensitivity_results (
    sensitivity_id INT NOT NULL AUTO_INCREMENT,
    event_id INT NOT NULL,
    scenario VARCHAR(255) NOT NULL,
    runoff_coefficient DOUBLE,
    PRIMARY KEY (sensitivity_id),
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ==========================================
-- DATA: BRAZIL (Events 1-2)
-- ==========================================

INSERT INTO events (event_name, country, year, event_type_main, event_type_secondary, description) VALUES
('Brazil Storm 2023','Brazil',2023,'Storm','Flood','Severe meteorological storm associated with flood hazard'),
('Brazil Flood 2023','Brazil',2023,'Flood','Storm','Flood impact based on total precipitation and surface runoff');

INSERT INTO event_summary (event_id, total_rainfall_mm, mean_rainfall_per_timestep_mm, rainfall_ci_low_mm, rainfall_ci_high_mm, total_runoff_mm, runoff_coefficient_ro_tp, n_timesteps) VALUES
(1, 65.82, 0.686, 0.671, 0.700, NULL, 0.115, 96),
(2, 153.95, 0.916, 0.903, 0.929, 21.57, 0.140, NULL);

INSERT INTO uncertainty_metrics (event_id, variable_name, n, mean_value, unit, std, cv, ci_low, ci_high, uncertainty_level) VALUES
(1, 'tp_mm', 50400, 0.686, 'mm', 1.69, 2.47, 0.671, 0.700, 'High'),
(1, 'ssro_mm', 50400, 0.161, 'mm', 0.37, 2.29, NULL, NULL, 'High'),
(1, 'RC_sro_over_tp', NULL, 0.115, NULL, NULL, 2.44, NULL, NULL, 'High'),
(2, 'tp_mm', NULL, 0.916, 'mm', 1.985, 2.166, 0.903, 0.929, NULL),
(2, 'sro_mm', NULL, 0.128, 'mm', 0.544, 4.234, 0.125, 0.132, NULL);

INSERT INTO sensitivity_results (event_id, scenario, runoff_coefficient) VALUES
(2, 'Base RC', 0.140),
(2, 'TP -10%', 0.156),
(2, 'TP +10%', 0.127);

-- ==========================================
-- DATA: ITALY (Events 3-4)
-- ==========================================

INSERT INTO events (event_name, country, year, event_type_main, event_type_secondary, description) VALUES
('Italy Emilia-Romagna Flood P1','Italy',2023,'Flood','Landslide','Catastrophic flood and landslides triggered by intense rain (May 2-3).'),
('Italy Emilia-Romagna Flood P2','Italy',2023,'Flood','Storm','Massive flooding event fueled by Storm Minerva (May 16-17).');

INSERT INTO event_summary (event_id, total_rainfall_mm, mean_rainfall_per_timestep_mm, rainfall_ci_low_mm, rainfall_ci_high_mm, total_runoff_mm, mean_runoff_per_timestep_mm, runoff_ci_low_mm, runoff_ci_high_mm, runoff_coefficient_ro_tp, n_timesteps) VALUES 
(3, 55.49, 1.156, 1.083, 1.229, 6.921, 0.144, 0.124, 0.164, 0.115, 48),
(4, 67.6266, 1.408888, 1.354, 1.463, 6.9209, 0.395327, 0.367, 0.423, 0.259, 48);

INSERT INTO uncertainty_metrics (event_id, variable_name, n, mean_value, unit, std, cv, ci_low, ci_high, uncertainty_level) VALUES 
(3, 'tp_mm', 1152, 1.156, 'mm', 1.271, 1.099, 1.083, 1.229, 'Moderate-High'),
(3, 'sro_mm', 1152, 0.133, 'mm', 0.336, 2.524, 0.114, 0.153, 'High'),
(4, 'tp_mm', 2880, 1.408888, 'mm', 1.492628, 1.059, 1.354, 1.463, 'Moderate-High'),
(4, 'sro_mm', 2880, 0.364952, 'mm', 0.728251, 1.995, 0.338, 0.392, 'High');

INSERT INTO sensitivity_results (event_id, scenario, runoff_coefficient) VALUES 
(3, 'Base RC', 0.1153), (3, 'TP -10%', 0.1281), (3, 'TP +10%', 0.1048),
(4, 'Base RC', 0.259036), (4, 'TP -10%', 0.287817), (4, 'TP +10%', 0.235487);

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;
COMMIT;