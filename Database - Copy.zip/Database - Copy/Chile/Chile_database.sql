PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_name TEXT NOT NULL,
    country TEXT,
    year INTEGER,
    event_type_main TEXT,
    event_type_secondary TEXT,
    description TEXT
);
INSERT INTO events VALUES(1,'USA Wildfire 2021','United States',2021,'Wildfire','Heat/Drought/Wind','Bootleg Fire and Western U.S. wildfire conditions');
INSERT INTO events VALUES(2,'USA Flood 2021','United States',2021,'Flood','Landslide/Mudslide','Flood associated with landslide and mudslide');
INSERT INTO events VALUES(3,'USA Severe Storm 2021','United States',2021,'Storm','Flood','Severe storm associated with flooding');
CREATE TABLE event_summary (
    summary_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    total_rainfall_mm REAL,
    mean_rainfall_per_timestep_mm REAL,
    rainfall_ci_low_mm REAL,
    rainfall_ci_high_mm REAL,
    total_runoff_mm REAL,
    mean_runoff_per_timestep_mm REAL,
    runoff_ci_low_mm REAL,
    runoff_ci_high_mm REAL,
    runoff_coefficient_ro_tp REAL,
    n_timesteps INTEGER,
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);
INSERT INTO event_summary VALUES(1,2,8.320000000000000284,0.05770000000000000128,0.05670000000000000039,0.05879999999999999811,0.3439999999999999724,0.002390000000000000197,0.002279999999999999909,0.002490000000000000025,0.04100000000000000172,144);
INSERT INTO event_summary VALUES(2,3,17.46999999999999887,0.1819999999999999952,0.1799999999999999934,0.1829999999999999961,1.024000000000000021,0.01069999999999999945,0.01030000000000000012,0.01099999999999999937,0.05859999999999999932,96);
CREATE TABLE uncertainty_metrics (
    uncertainty_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    variable_name TEXT NOT NULL,
    n INTEGER,
    mean_value REAL,
    unit TEXT,
    std REAL,
    cv REAL,
    ci_low REAL,
    ci_high REAL,
    uncertainty_level TEXT,
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);
INSERT INTO uncertainty_metrics VALUES(1,2,'tp_mm',297648,0.05770000000000000128,'mm',0.2945999999999999729,5.099999999999999645,0.05670000000000000039,0.05879999999999999811,NULL);
INSERT INTO uncertainty_metrics VALUES(2,2,'sro_mm',297648,0.002390000000000000197,'mm',0.02852999999999999981,11.94999999999999929,0.002279999999999999909,0.002490000000000000025,NULL);
INSERT INTO uncertainty_metrics VALUES(3,2,'ssro_mm',297648,0.0005500000000000000331,'mm',NULL,5.139999999999999681,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(4,2,'u10_mps',297648,-0.2240000000000000046,'m/s',1.820999999999999953,-8.119999999999999218,-0.2310000000000000108,-0.2179999999999999994,NULL);
INSERT INTO uncertainty_metrics VALUES(5,2,'v10_mps',297648,1.008000000000000007,'m/s',1.745999999999999997,1.729999999999999983,0.948999999999999955,1.06800000000000006,NULL);
INSERT INTO uncertainty_metrics VALUES(6,2,'wind_speed_10m_mps',297648,2.345000000000000195,'m/s',1.387999999999999901,0.589999999999999969,2.339999999999999858,2.350000000000000088,NULL);
INSERT INTO uncertainty_metrics VALUES(7,2,'swvl1',NULL,0.1300000000000000044,'m3/m3',NULL,0.7399999999999999912,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(8,2,'swvl2',NULL,0.1600000000000000033,'m3/m3',NULL,0.5500000000000000444,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(9,2,'swvl3',NULL,0.1680000000000000104,'m3/m3',NULL,0.4199999999999999845,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(10,2,'swvl4',NULL,0.1970000000000000084,'m3/m3',NULL,0.2899999999999999801,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(11,3,'tp_mm',633888,0.1819999999999999952,'mm',0.776000000000000023,4.259999999999999787,0.1799999999999999934,0.1829999999999999961,NULL);
INSERT INTO uncertainty_metrics VALUES(12,3,'sro_mm',633888,0.01069999999999999945,'mm',0.1330000000000000071,12.44999999999999929,0.01030000000000000012,0.01099999999999999937,'Extremely High');
INSERT INTO uncertainty_metrics VALUES(13,3,'ssro_mm',633888,0.007289999999999999606,'mm',NULL,4.259999999999999787,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(14,3,'u10_mps',633888,-0.7379999999999999894,'m/s',2.169000000000000039,-2.939999999999999947,-0.7439999999999999947,-0.732999999999999985,NULL);
INSERT INTO uncertainty_metrics VALUES(15,3,'v10_mps',633888,1.032000000000000028,'m/s',3.003000000000000113,2.910000000000000142,0.9130000000000000337,1.153000000000000024,NULL);
INSERT INTO uncertainty_metrics VALUES(16,3,'wind_speed_10m_mps',633888,3.428999999999999826,'m/s',1.891000000000000014,0.5500000000000000444,3.423999999999999933,3.43299999999999983,NULL);
INSERT INTO uncertainty_metrics VALUES(17,3,'swvl1',NULL,0.2439999999999999947,'m3/m3',NULL,0.5200000000000000177,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(18,3,'swvl2',NULL,0.2399999999999999912,'m3/m3',NULL,0.4699999999999999734,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(19,3,'swvl3',NULL,0.2270000000000000073,'m3/m3',NULL,0.4600000000000000199,NULL,NULL,NULL);
INSERT INTO uncertainty_metrics VALUES(20,3,'swvl4',NULL,0.2540000000000000035,'m3/m3',NULL,0.4600000000000000199,NULL,NULL,NULL);
CREATE TABLE sensitivity_results (
    sensitivity_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    scenario TEXT NOT NULL,
    runoff_coefficient REAL,
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);
INSERT INTO sensitivity_results VALUES(1,2,'Base RC',0.04100000000000000172);
INSERT INTO sensitivity_results VALUES(2,2,'RC if TP -10%',0.04599999999999999923);
INSERT INTO sensitivity_results VALUES(3,2,'RC if TP +10%',0.03799999999999999906);
INSERT INTO sensitivity_results VALUES(4,3,'Base RC',0.05859999999999999932);
INSERT INTO sensitivity_results VALUES(5,3,'RC if TP -10%',0.06519999999999999407);
INSERT INTO sensitivity_results VALUES(6,3,'RC if TP +10%',0.05330000000000000015);
CREATE TABLE hazard_context (
    context_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    factor_name TEXT NOT NULL,
    variable_code TEXT,
    description TEXT,
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);
INSERT INTO hazard_context VALUES(1,1,'Extreme Thermal Stress','2T@SFC','Extreme and spatially extensive heat affected California, Nevada, Arizona, and southern Oregon, with the highest temperature class ranging from 306.293 to 321.588 K. These conditions reduced vegetation moisture and intensified wildfire susceptibility.');
INSERT INTO hazard_context VALUES(2,1,'Surface Pressure Gradients','SP@SFC','Surface pressure ranged from about 71372 to 102719 Pa. Strong gradients across the western United States supported subsidence, wind acceleration, reduced cloud formation, and persistence of hazardous environmental conditions.');
INSERT INTO hazard_context VALUES(3,1,'Surface Soil Moisture','SWVL1','SWVL1 values ranged from about -0.007 to 0.519 m3/m3. Large parts of California, Nevada, Arizona, and southern Oregon were in the driest classes, indicating extremely dry surface conditions.');
INSERT INTO hazard_context VALUES(4,1,'Shallow Root-Zone Soil Moisture','SWVL2','SWVL2 ranged from about -0.002 to 0.511 m3/m3. Widespread low values across California, Nevada, Arizona, southern Utah, Oregon, and Idaho showed persistent shallow subsurface dryness.');
INSERT INTO hazard_context VALUES(5,1,'Intermediate Soil Moisture','SWVL3','SWVL3 ranged from about -0.0004 to 0.421 m3/m3. Lower classes dominated California, Nevada, Arizona, and southern Oregon, confirming drought extension into the soil profile.');
INSERT INTO hazard_context VALUES(6,1,'Deep Soil Moisture','SWVL4','SWVL4 ranged from 0 to 0.474 m3/m3. Low deep moisture availability across California, Nevada, Arizona, Utah, and parts of Oregon indicated prolonged drought conditions.');
INSERT INTO hazard_context VALUES(7,1,'Zonal Wind Forcing','10U@SFC','10U ranged from -8.044 to 3.541 m/s. Easterly to weakly variable zonal winds dominated, supporting sustained atmospheric transport and boundary-layer forcing.');
INSERT INTO hazard_context VALUES(8,1,'Meridional Wind Forcing','10V@SFC','10V ranged from -14.573 to 10.868 m/s. Strong north-south variability reflected sustained synoptic-scale circulation and enhanced atmospheric transport.');
INSERT INTO hazard_context VALUES(9,1,'Wildfire Hazard Interpretation',NULL,'The Bootleg Fire event was driven by extreme thermal stress, prolonged drought, low soil moisture, strong near-surface winds, and persistent pressure gradients, creating highly favorable conditions for ignition and rapid fire spread.');
PRAGMA writable_schema=ON;
CREATE TABLE IF NOT EXISTS sqlite_sequence(name,seq);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('events',3);
INSERT INTO sqlite_sequence VALUES('event_summary',2);
INSERT INTO sqlite_sequence VALUES('uncertainty_metrics',20);
INSERT INTO sqlite_sequence VALUES('sensitivity_results',6);
INSERT INTO sqlite_sequence VALUES('hazard_context',9);
PRAGMA writable_schema=OFF;
COMMIT;
